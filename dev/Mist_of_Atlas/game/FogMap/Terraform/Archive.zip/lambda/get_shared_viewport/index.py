from boto3.dynamodb.conditions import Key
from shared.common import dynamodb, utc_now_iso
from shared.config import LANDMARKS_TABLE, PLAYER_PRESENCE_TABLE, SHARED_CELLS_TABLE
from shared.geo import in_bounds, tile_ids_for_bounds

shared_cells_table = dynamodb.Table(SHARED_CELLS_TABLE)
presence_table = dynamodb.Table(PLAYER_PRESENCE_TABLE)
landmarks_table = dynamodb.Table(LANDMARKS_TABLE)

def handler(event, context):
    args = event.get("arguments") or {}
    world_id = (args.get("worldId") or "global").strip().lower()
    min_lat,max_lat,min_lon,max_lon,zoom = float(args["minLat"]),float(args["maxLat"]),float(args["minLon"]),float(args["maxLon"]),int(args["zoom"])
    cells=[]; players=[]; landmarks=[]
    for tile_id in tile_ids_for_bounds(min_lat,max_lat,min_lon,max_lon,zoom)[:150]:
        for item in shared_cells_table.query(KeyConditionExpression=Key("pk").eq(f"WORLD#{world_id}#TILE#{tile_id}")).get("Items", []):
            lat=float(item["lat"]); lon=float(item["lon"])
            if in_bounds(lat,lon,min_lat,max_lat,min_lon,max_lon): cells.append({"cellId":str(item["sk"]).replace("CELL#",""),"lat":lat,"lon":lon,"discovererCount":int(item.get("discovererCount",1)),"tileId":item.get("tileId",tile_id),"lastDiscoveredAt":item.get("lastDiscoveredAt",utc_now_iso())})
        for item in presence_table.query(KeyConditionExpression=Key("pk").eq(f"WORLD#{world_id}#TILE#{tile_id}")).get("Items", []):
            lat=float(item["lat"]); lon=float(item["lon"])
            if in_bounds(lat,lon,min_lat,max_lat,min_lon,max_lon): players.append({"userId":item["userId"],"displayName":item.get("displayName","Explorer"),"lat":lat,"lon":lon,"lastSeenAt":item.get("lastSeenAt",utc_now_iso())})
        for item in landmarks_table.query(KeyConditionExpression=Key("pk").eq(f"WORLD#{world_id}#TILE#{tile_id}")).get("Items", []):
            if item.get("status") != "APPROVED": continue
            lat=float(item["lat"]); lon=float(item["lon"])
            if in_bounds(lat,lon,min_lat,max_lat,min_lon,max_lon): landmarks.append({"landmarkId":item["landmarkId"],"title":item.get("title",""),"description":item.get("description",""),"category":item.get("category",""),"lat":lat,"lon":lon,"status":item.get("status","APPROVED"),"approvedObjectKey":item.get("approvedObjectKey"),"createdAt":item.get("createdAt",utc_now_iso())})
    return {"worldId":world_id,"cells":cells,"players":players,"landmarks":landmarks,"generatedAt":utc_now_iso()}
