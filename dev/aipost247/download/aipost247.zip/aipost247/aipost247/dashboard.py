"""Local web dashboard — configure and monitor AIPost247 in the browser.

Run with ``python run.py dashboard`` (or just ``run.bat`` / ``./run.sh`` with no
arguments). Serves a single-page UI on http://localhost:8730 plus a small JSON
API. Everything stays on your machine; secrets are never sent to the browser.
"""
from __future__ import annotations

import json
import threading
import time
import webbrowser
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import config as cfg
from .logging_setup import get_logger
from .memory import MemoryStore

log = get_logger("dashboard")

DEFAULT_PORT = 8730


# --------------------------------------------------------------------------
# Autopilot — runs the posting loop in a background thread (start/stop from UI)
# --------------------------------------------------------------------------
class Autopilot:
    def __init__(self) -> None:
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self.last_run_at: str | None = None
        self.last_result: str | None = None
        self.next_run_at: str | None = None

    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self, memory: MemoryStore) -> None:
        if self.running():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, args=(memory,), daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self.next_run_at = None

    def _seconds_until_next(self, config) -> float:
        if config.schedule_mode == "daily" and config.schedule_times:
            now = datetime.now()
            best = None
            for t in config.schedule_times:
                try:
                    hh, mm = (int(x) for x in t.split(":"))
                except ValueError:
                    continue
                target = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
                delta = (target - now).total_seconds()
                if delta <= 0:
                    delta += 86400
                best = delta if best is None else min(best, delta)
            return best if best is not None else 3600.0
        return max(60.0, config.schedule_interval_minutes * 60.0)

    def _run_once(self, memory: MemoryStore) -> None:
        from . import app as _app
        from .facebook_client import FacebookClient

        config = cfg.load_config()
        fb = FacebookClient(
            config.fb_page_id, config.fb_page_access_token,
            app_id=config.fb_app_id, app_secret=config.fb_app_secret,
            api_version=config.graph_api_version,
        )
        ok = _app.safe_cycle(config, memory, fb, dry_run=config.dry_run)
        self.last_run_at = datetime.now().isoformat(timespec="seconds")
        self.last_result = "ok" if ok else "failed"

    def _loop(self, memory: MemoryStore) -> None:
        config = cfg.load_config()
        if config.run_on_start:
            self._run_once(memory)
        while not self._stop.is_set():
            config = cfg.load_config()
            wait = self._seconds_until_next(config)
            self.next_run_at = datetime.fromtimestamp(time.time() + wait).isoformat(timespec="seconds")
            end = time.time() + wait
            while time.time() < end and not self._stop.is_set():
                time.sleep(min(1.0, max(0.05, end - time.time())))
            if self._stop.is_set():
                break
            self._run_once(memory)


_AUTOPILOT = Autopilot()


# --------------------------------------------------------------------------
# Data helpers
# --------------------------------------------------------------------------
def _status(memory: MemoryStore) -> dict:
    from . import gemini_client

    config = cfg.load_config()
    gemini_ok = False
    if config.ai_provider != "openai":
        try:
            gemini_ok = gemini_client.is_authenticated(config.gemini_model)
        except Exception:  # noqa: BLE001
            gemini_ok = False
    return {
        "ai_provider": config.ai_provider,
        "ai_ready": config.ai_ready() and (config.ai_provider == "openai" or gemini_ok),
        "gemini_logged_in": gemini_ok,
        "facebook_connected": bool(config.fb_page_id and config.fb_page_access_token),
        "facebook_page_id": config.fb_page_id,
        "configured": config.is_ready(),
        "missing": config.missing(),
        "schedule": _schedule_text(config),
        "dry_run": config.dry_run,
        "post_language": config.post_language,
        "stats": memory.stats(),
        "autopilot": {
            "running": _AUTOPILOT.running(),
            "last_run_at": _AUTOPILOT.last_run_at,
            "last_result": _AUTOPILOT.last_result,
            "next_run_at": _AUTOPILOT.next_run_at,
        },
    }


def _schedule_text(config) -> str:
    if config.schedule_mode == "daily":
        return "всеки ден в " + ", ".join(config.schedule_times) if config.schedule_times else "всеки ден"
    mins = config.schedule_interval_minutes
    return f"на всеки {mins // 60} ч" if mins % 60 == 0 and mins >= 60 else f"на всеки {mins} мин"


def _config_public(config) -> dict:
    """Config for the UI — secrets are reported as booleans only, never sent."""
    return {
        "ai_provider": config.ai_provider,
        "gemini_model": config.gemini_model or cfg.DEFAULT_GEMINI_MODEL,
        "openai_model": config.openai_model or cfg.DEFAULT_OPENAI_MODEL,
        "has_openai_key": bool(config.openai_api_key),
        "fb_page_id": config.fb_page_id,
        "has_fb_token": bool(config.fb_page_access_token),
        "fb_app_id": config.fb_app_id,
        "has_fb_app_secret": bool(config.fb_app_secret),
        "graph_api_version": config.graph_api_version or cfg.DEFAULT_GRAPH_VERSION,
        "schedule_mode": config.schedule_mode,
        "schedule_interval_minutes": config.schedule_interval_minutes,
        "schedule_times": ",".join(config.schedule_times),
        "run_on_start": config.run_on_start,
        "dry_run": config.dry_run,
        "post_max_chars": config.post_max_chars,
        "post_language": config.post_language,
    }


def _save_config(data: dict) -> None:
    existing = cfg.load_config()
    values: dict[str, str] = {
        "AI_PROVIDER": data.get("ai_provider", existing.ai_provider) or "gemini",
        "GEMINI_MODEL": data.get("gemini_model") or existing.gemini_model or cfg.DEFAULT_GEMINI_MODEL,
        "OPENAI_MODEL": data.get("openai_model") or existing.openai_model or cfg.DEFAULT_OPENAI_MODEL,
        "GRAPH_API_VERSION": data.get("graph_api_version") or existing.graph_api_version,
        "SCHEDULE_MODE": data.get("schedule_mode", existing.schedule_mode) or "interval",
        "SCHEDULE_INTERVAL_MINUTES": str(data.get("schedule_interval_minutes") or existing.schedule_interval_minutes),
        "SCHEDULE_TIMES": data.get("schedule_times") or ",".join(existing.schedule_times),
        "RUN_ON_START": "true" if data.get("run_on_start", existing.run_on_start) else "false",
        "DRY_RUN": "true" if data.get("dry_run", existing.dry_run) else "false",
        "POST_MAX_CHARS": str(data.get("post_max_chars") or existing.post_max_chars),
        "POST_LANGUAGE": data.get("post_language") or existing.post_language or "Bulgarian",
    }
    # Secrets: only overwrite when a non-empty value is supplied.
    if data.get("openai_api_key"):
        values["OPENAI_API_KEY"] = data["openai_api_key"]
    if data.get("fb_page_id"):
        values["FB_PAGE_ID"] = data["fb_page_id"]
    if data.get("fb_page_access_token"):
        values["FB_PAGE_ACCESS_TOKEN"] = data["fb_page_access_token"]
    if data.get("fb_app_id"):
        values["FB_APP_ID"] = data["fb_app_id"]
    if data.get("fb_app_secret"):
        values["FB_APP_SECRET"] = data["fb_app_secret"]
    cfg._write_env(values)


def _do_cycle(memory: MemoryStore, dry_run: bool) -> dict:
    from . import app as _app, engagement
    from .facebook_client import FacebookClient, FacebookError

    config = cfg.load_config()
    try:
        fb = FacebookClient(
            config.fb_page_id, config.fb_page_access_token,
            app_id=config.fb_app_id, app_secret=config.fb_app_secret,
            api_version=config.graph_api_version,
        )
        try:
            engagement.learn(memory, fb, cfg.MEMORY_DIR)
        except Exception:  # noqa: BLE001 - learning must never block a post
            pass
        text = _app.generate_text(config, memory.build_context())
        if dry_run:
            memory.add_post(text, fb_post_id=None, status="dry_run", model=config.ai_provider)
            return {"ok": True, "published": False, "text": text}
        post_id = fb.post(text)
        memory.add_post(text, fb_post_id=post_id, status="published", model=config.ai_provider)
        return {"ok": True, "published": True, "post_id": post_id, "text": text}
    except FacebookError as exc:
        return {"ok": False, "error": f"Facebook: {exc}"}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": str(exc)}


def _tail_log(lines: int = 200) -> str:
    path = cfg.LOGS_DIR / "aipost247.log"
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            return "".join(fh.readlines()[-lines:])
    except OSError:
        return "(няма лог файл още)"


# --------------------------------------------------------------------------
# HTTP handler
# --------------------------------------------------------------------------
class _Handler(BaseHTTPRequestHandler):
    memory: MemoryStore = None  # type: ignore[assignment]

    def _send(self, code: int, body: bytes, ctype: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code: int = 200) -> None:
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8")

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0) or 0)
        if not length:
            return {}
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return {}

    def log_message(self, *_args):  # silence default access logging
        return

    # -- GET --------------------------------------------------------------
    def do_GET(self):  # noqa: N802
        path = self.path.split("?", 1)[0]
        if path in ("/", "/index.html"):
            self._send(200, _PAGE.encode("utf-8"), "text/html; charset=utf-8")
        elif path == "/api/status":
            self._json(_status(self.memory))
        elif path == "/api/config":
            self._json(_config_public(cfg.load_config()))
        elif path == "/api/posts":
            self._json({"posts": self.memory.recent_posts_detailed(60)})
        elif path == "/api/memory":
            self._json({
                "business": self.memory.read_business_file(),
                "skill": self.memory.read_skill_file(),
                "steering": self.memory.read_steering_file(),
                "instructions": self.memory.get_instructions(),
            })
        elif path == "/api/logs":
            self._json({"log": _tail_log()})
        else:
            self._json({"error": "not found"}, 404)

    # -- POST -------------------------------------------------------------
    def do_POST(self):  # noqa: N802
        path = self.path.split("?", 1)[0]
        data = self._body()
        try:
            if path == "/api/config":
                _save_config(data)
                self._json({"ok": True})
            elif path == "/api/generate":
                self._json(_do_cycle(self.memory, dry_run=True))
            elif path == "/api/post-now":
                self._json(_do_cycle(self.memory, dry_run=False))
            elif path == "/api/learn":
                self._json(self._learn())
            elif path == "/api/login-gemini":
                self._json(self._login_gemini())
            elif path == "/api/facebook/connect":
                self._json(self._fb_connect(data))
            elif path == "/api/business":
                self._json(self._save_business(data))
            elif path == "/api/feedback":
                self._json(self._feedback(data))
            elif path == "/api/autopilot":
                self._json(self._autopilot(data))
            else:
                self._json({"error": "not found"}, 404)
        except Exception as exc:  # noqa: BLE001 - never 500 silently
            log.exception("Dashboard API error on %s", path)
            self._json({"ok": False, "error": str(exc)}, 200)

    # -- action implementations ------------------------------------------
    def _learn(self) -> dict:
        from . import engagement
        from .facebook_client import FacebookClient, FacebookError

        config = cfg.load_config()
        fb = FacebookClient(
            config.fb_page_id, config.fb_page_access_token,
            app_id=config.fb_app_id, app_secret=config.fb_app_secret,
            api_version=config.graph_api_version,
        )
        try:
            updated = engagement.sync(self.memory, fb)
            engagement.write_skill_md(self.memory, cfg.MEMORY_DIR)
            return {"ok": True, "updated": updated}
        except FacebookError as exc:
            return {"ok": False, "error": str(exc)}

    def _login_gemini(self) -> dict:
        from . import gemini_client

        config = cfg.load_config()
        try:
            ok = gemini_client.login(config.gemini_model)
            return {"ok": ok, "logged_in": gemini_client.is_authenticated(config.gemini_model)}
        except gemini_client.GeminiError as exc:
            return {"ok": False, "error": str(exc)}

    def _fb_connect(self, data: dict) -> dict:
        from .facebook_client import FacebookError
        from .fb_oauth import login_and_select_page

        app_id = (data.get("fb_app_id") or "").strip()
        app_secret = (data.get("fb_app_secret") or "").strip()
        if not (app_id and app_secret):
            existing = cfg.load_config()
            app_id = app_id or existing.fb_app_id
            app_secret = app_secret or existing.fb_app_secret
        if not (app_id and app_secret):
            return {"ok": False, "error": "Нужни са App ID и App Secret."}
        try:
            api = cfg.load_config().graph_api_version or cfg.DEFAULT_GRAPH_VERSION
            page_id, token, name = login_and_select_page(
                app_id, app_secret, api, choose=lambda pages: pages[0]
            )
            cfg._write_env({
                "FB_APP_ID": app_id, "FB_APP_SECRET": app_secret,
                "FB_PAGE_ID": page_id, "FB_PAGE_ACCESS_TOKEN": token,
            })
            return {"ok": True, "page_name": name, "page_id": page_id}
        except FacebookError as exc:
            return {"ok": False, "error": str(exc)}

    def _save_business(self, data: dict) -> dict:
        from . import business

        profile = {k: (data.get(k) or "").strip() for k, _l, _m in business.FIELDS}
        if not any(profile.values()):
            return {"ok": False, "error": "Празна форма."}
        path = business.save_profile(cfg.MEMORY_DIR, profile)
        return {"ok": True, "path": str(path)}

    def _feedback(self, data: dict) -> dict:
        from . import app as _app

        text = (data.get("feedback") or "").strip()
        if not text:
            return {"ok": False, "error": "Празна обратна връзка."}
        consolidated = _app._consolidate_steering(cfg.load_config(), self.memory, text)
        return {"ok": True, "ai_consolidated": consolidated,
                "steering": self.memory.read_steering_file()}

    def _autopilot(self, data: dict) -> dict:
        action = data.get("action")
        if action == "start":
            if not cfg.load_config().is_ready():
                return {"ok": False, "error": "Първо завършете настройката."}
            _AUTOPILOT.start(self.memory)
        elif action == "stop":
            _AUTOPILOT.stop()
        return {"ok": True, "running": _AUTOPILOT.running()}


# --------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------
def run_dashboard(port: int = DEFAULT_PORT, open_browser: bool = True) -> int:
    cfg.ensure_dirs()
    _Handler.memory = MemoryStore(str(cfg.DB_PATH), str(cfg.MEMORY_DIR))
    try:
        server = ThreadingHTTPServer(("127.0.0.1", port), _Handler)
    except OSError as exc:
        log.error("Не мога да стартирам таблото на порт %d: %s", port, exc)
        return 1
    url = f"http://localhost:{port}/"
    print("\n  " + "=" * 58)
    print(f"  AIPost247 · Таблото е активно:  {url}")
    print("  Отворете го в браузъра. Спрете с Ctrl+C.")
    print("  " + "=" * 58 + "\n")
    if open_browser:
        try:
            webbrowser.open(url)
        except Exception:  # noqa: BLE001
            pass
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  Таблото е спряно.")
    finally:
        _AUTOPILOT.stop()
        server.server_close()
        _Handler.memory.close()
    return 0


_PAGE = r"""<!DOCTYPE html>
<html lang="bg"><head><meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>AIPost247 · Табло</title>
<style>
  :root{--bg:#eef1f7;--card:#fff;--ink:#16202c;--muted:#5b6b7e;--line:#e2e8f2;
    --accent:#1877f2;--accent-ink:#0b5fd0;--ok:#1f9d57;--bad:#d3392b;--warn:#c9921b;--radius:14px;}
  *{box-sizing:border-box;}
  body{margin:0;background:var(--bg);color:var(--ink);
    font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;}
  header{background:linear-gradient(135deg,#1877f2,#0b5fd0);color:#fff;padding:18px 24px;
    display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;}
  header h1{margin:0;font-size:1.25rem;}
  header .sub{opacity:.9;font-size:.85rem;}
  .pillbar{display:flex;gap:8px;flex-wrap:wrap;}
  .pill{font-size:.78rem;font-weight:700;padding:5px 11px;border-radius:999px;background:rgba(255,255,255,.18);border:1px solid rgba(255,255,255,.3);}
  .pill.ok{background:rgba(31,157,87,.22);border-color:rgba(255,255,255,.4);}
  .pill.bad{background:rgba(211,57,43,.28);border-color:rgba(255,255,255,.4);}
  .wrap{max-width:1040px;margin:0 auto;padding:18px;}
  nav{display:flex;gap:6px;margin:14px 0 18px;flex-wrap:wrap;}
  nav button{cursor:pointer;border:1px solid var(--line);background:#fff;color:var(--ink);
    font:inherit;font-weight:600;padding:9px 16px;border-radius:999px;}
  nav button.active{background:var(--accent);color:#fff;border-color:var(--accent);}
  .card{background:var(--card);border:1px solid var(--line);border-radius:var(--radius);
    padding:18px 20px;margin-bottom:16px;box-shadow:0 10px 26px -22px rgba(16,32,44,.5);}
  .card h2{margin:0 0 4px;font-size:1.05rem;}
  .card .hint{color:var(--muted);font-size:.85rem;margin:0 0 14px;}
  label{display:block;font-weight:600;margin:12px 0 4px;font-size:.9rem;}
  input,select,textarea{width:100%;padding:9px 11px;border:1px solid var(--line);border-radius:9px;
    font:inherit;color:var(--ink);background:#fff;}
  input:focus,select:focus,textarea:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px rgba(24,119,242,.15);}
  textarea{resize:vertical;min-height:70px;}
  .row{display:flex;gap:14px;flex-wrap:wrap;}
  .row>div{flex:1;min-width:180px;}
  .check{display:flex;align-items:center;gap:8px;margin-top:12px;}
  .check input{width:auto;}
  button.btn{cursor:pointer;border:none;border-radius:10px;font:inherit;font-weight:700;
    padding:10px 18px;background:var(--accent);color:#fff;margin-top:14px;}
  button.btn:hover{background:var(--accent-ink);}
  button.btn.ghost{background:#eef2f8;color:var(--ink);}
  button.btn.ok{background:var(--ok);}
  button.btn.bad{background:var(--bad);}
  .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;}
  .stat{background:#f7f9fd;border:1px solid var(--line);border-radius:12px;padding:12px 14px;}
  .stat .n{font-size:1.5rem;font-weight:800;}
  .stat .l{color:var(--muted);font-size:.8rem;}
  table{width:100%;border-collapse:collapse;font-size:.88rem;}
  th,td{text-align:left;padding:9px 10px;border-bottom:1px solid var(--line);vertical-align:top;}
  th{color:var(--muted);font-weight:600;background:#f7f9fd;}
  .tag{font-size:.72rem;font-weight:700;padding:2px 8px;border-radius:999px;}
  .tag.published{background:#e4f6ec;color:#1f7a48;}
  .tag.dry_run{background:#fff4e0;color:#9a6b12;}
  .tag.failed{background:#fde4e1;color:#a82d22;}
  pre.log{background:#0f1722;color:#dbe6f5;border-radius:10px;padding:14px;overflow:auto;max-height:60vh;
    font:12px/1.5 ui-monospace,Menlo,Consolas,monospace;white-space:pre-wrap;}
  .toast{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);background:#16202c;color:#fff;
    padding:11px 18px;border-radius:10px;box-shadow:0 14px 34px -12px rgba(0,0,0,.5);opacity:0;
    transition:opacity .25s,transform .25s;pointer-events:none;z-index:50;}
  .toast.show{opacity:1;transform:translateX(-50%) translateY(-4px);}
  .out{background:#f7f9fd;border:1px solid var(--line);border-radius:10px;padding:12px;margin-top:12px;white-space:pre-wrap;}
  .muted{color:var(--muted);}
  .hide{display:none;}
  .busy{opacity:.6;pointer-events:none;}
</style></head>
<body>
<header>
  <div><h1>AIPost247 · Табло</h1><div class="sub">Конфигурирайте и наблюдавайте — без терминал.</div></div>
  <div class="pillbar" id="pills"></div>
</header>
<div class="wrap">
  <nav>
    <button data-tab="overview" class="active">Преглед</button>
    <button data-tab="setup">Настройка</button>
    <button data-tab="business">Бизнес &amp; стил</button>
    <button data-tab="posts">Публикации</button>
    <button data-tab="logs">Дневник</button>
  </nav>

  <!-- OVERVIEW -->
  <section id="tab-overview">
    <div class="card">
      <h2>Състояние</h2>
      <div class="grid" id="stats"></div>
      <div style="margin-top:14px" id="autopilot-box"></div>
    </div>
    <div class="card">
      <h2>Бързи действия</h2>
      <p class="hint">Генерирайте за преглед, публикувайте веднага или опреснете ангажираността.</p>
      <button class="btn ghost" onclick="act('/api/generate','Генерирам…')">Генерирай (преглед)</button>
      <button class="btn" onclick="act('/api/post-now','Публикувам…')">Публикувай сега</button>
      <button class="btn ghost" onclick="act('/api/learn','Уча от ангажираността…')">Опресни наученото</button>
      <div id="action-out" class="out hide"></div>
    </div>
  </section>

  <!-- SETUP -->
  <section id="tab-setup" class="hide">
    <div class="card">
      <h2>1 · AI, който пише</h2>
      <label>Доставчик</label>
      <select id="ai_provider">
        <option value="gemini">Gemini — вход с Google (без ключ)</option>
        <option value="openai">OpenAI — с API ключ</option>
      </select>
      <div id="gemini-box">
        <label>Gemini модел</label>
        <input id="gemini_model"/>
        <button class="btn ghost" onclick="loginGemini()">Вход в Google за Gemini</button>
        <span id="gemini-status" class="muted"></span>
      </div>
      <div id="openai-box" class="hide">
        <div class="row">
          <div><label>OpenAI модел</label><input id="openai_model"/></div>
          <div><label>OpenAI API ключ <span id="openai-have" class="muted"></span></label>
            <input id="openai_api_key" type="password" placeholder="(оставете празно за да запазите)"/></div>
        </div>
      </div>
    </div>

    <div class="card">
      <h2>2 · Facebook страница</h2>
      <p class="hint">Поставете App ID и App Secret от вашето Meta приложение, после „Свържи“. Отваря се браузър за вход и избор на страница.</p>
      <div class="row">
        <div><label>App ID</label><input id="fb_app_id"/></div>
        <div><label>App Secret <span id="fb-have-secret" class="muted"></span></label>
          <input id="fb_app_secret" type="password" placeholder="(оставете празно за да запазите)"/></div>
      </div>
      <button class="btn" onclick="fbConnect()">Свържи Facebook</button>
      <span id="fb-status" class="muted"></span>
    </div>

    <div class="card">
      <h2>3 · График и поведение</h2>
      <div class="row">
        <div><label>Режим</label>
          <select id="schedule_mode">
            <option value="interval">През интервал</option>
            <option value="daily">Всеки ден в часове</option>
          </select></div>
        <div id="interval-box"><label>Интервал (минути)</label><input id="schedule_interval_minutes" type="number" min="1"/></div>
        <div id="times-box" class="hide"><label>Часове (HH:MM, със запетая)</label><input id="schedule_times" placeholder="09:00,18:00"/></div>
      </div>
      <div class="row">
        <div><label>Език на публикациите</label>
          <select id="post_language">
            <option value="Bulgarian">Български</option>
            <option value="English">English</option>
          </select></div>
        <div><label>Макс. дължина (символи)</label><input id="post_max_chars" type="number" min="50"/></div>
      </div>
      <div class="check"><input type="checkbox" id="run_on_start"/><label style="margin:0">Публикувай веднага при стартиране</label></div>
      <div class="check"><input type="checkbox" id="dry_run"/><label style="margin:0">Тестов режим (пише, но НЕ публикува)</label></div>
      <button class="btn ok" onclick="saveConfig()">Запази настройките</button>
    </div>
  </section>

  <!-- BUSINESS -->
  <section id="tab-business" class="hide">
    <div class="card">
      <h2>Профил на бизнеса</h2>
      <p class="hint">Кратък профил, за да звучат публикациите като вас.</p>
      <div id="business-fields"></div>
      <button class="btn ok" onclick="saveBusiness()">Запази профила</button>
    </div>
    <div class="card">
      <h2>Насочване на стила (само-коригиращо се)</h2>
      <p class="hint">Напишете какво да се промени — AI съгласува указанията в единен стил без противоречия.</p>
      <textarea id="feedback" placeholder="напр. по-кратко, повече емоджи, по-малко продажбено"></textarea>
      <button class="btn" onclick="sendFeedback()">Приложи</button>
      <label style="margin-top:16px">Текущ стил (steering.md)</label>
      <pre class="log" id="steering-view" style="max-height:30vh"></pre>
    </div>
  </section>

  <!-- POSTS -->
  <section id="tab-posts" class="hide">
    <div class="card">
      <h2>Публикации и изпълнения</h2>
      <p class="hint">Последните генерирания/публикувания с ангажираност.</p>
      <div style="overflow:auto"><table id="posts-table"><thead><tr>
        <th>Време</th><th>Статус</th><th>Текст</th><th>👍</th><th>💬</th><th>↗</th></tr></thead>
        <tbody id="posts-body"></tbody></table></div>
    </div>
  </section>

  <!-- LOGS -->
  <section id="tab-logs" class="hide">
    <div class="card">
      <h2>Дневник</h2>
      <p class="hint">Последните редове от logs/aipost247.log (опреснява се автоматично).</p>
      <pre class="log" id="log-view">…</pre>
    </div>
  </section>
</div>
<div class="toast" id="toast"></div>

<script>
var BIZ = [["name","Име на бизнеса / страницата"],["description","С какво се занимавате"],
  ["audience","Аудитория"],["tone","Тон и стил"],["topics","Теми за публикуване"],
  ["avoid","Какво да се избягва"],["cta","Подкана за действие"],["links","Връзки / профили"],
  ["notes","Друго, което AI трябва да знае"]];

function $(id){return document.getElementById(id);}
function toast(m){var t=$("toast");t.textContent=m;t.classList.add("show");setTimeout(function(){t.classList.remove("show");},2200);}
function getJSON(u){return fetch(u).then(function(r){return r.json();});}
function postJSON(u,b){return fetch(u,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b||{})}).then(function(r){return r.json();});}

// tabs
document.querySelectorAll("nav button").forEach(function(b){
  b.addEventListener("click",function(){
    document.querySelectorAll("nav button").forEach(function(x){x.classList.remove("active");});
    b.classList.add("active");
    document.querySelectorAll("section").forEach(function(s){s.classList.add("hide");});
    $("tab-"+b.dataset.tab).classList.remove("hide");
    if(b.dataset.tab==="posts")loadPosts();
    if(b.dataset.tab==="logs")loadLogs();
    if(b.dataset.tab==="business")loadMemory();
  });
});

// build business fields
(function(){var c=$("business-fields");BIZ.forEach(function(f){
  c.insertAdjacentHTML("beforeend","<label>"+f[1]+"</label><textarea id=\"biz_"+f[0]+"\" rows=\"2\"></textarea>");});})();

function pill(label,ok){return '<span class="pill '+(ok?"ok":"bad")+'">'+(ok?"✓ ":"✕ ")+label+'</span>';}

function loadStatus(){
  getJSON("/api/status").then(function(s){
    $("pills").innerHTML = pill("AI",s.ai_ready)+pill("Facebook",s.facebook_connected)+
      '<span class="pill">'+s.schedule+'</span>'+
      '<span class="pill '+(s.autopilot.running?"ok":"")+'">'+(s.autopilot.running?"▶ автопилот":"❚❚ спрян")+'</span>';
    var st=s.stats;
    $("stats").innerHTML =
      stat(st.total,"Общо")+stat(st.published,"Публикувани")+stat(st.dry_run,"Тестови")+
      stat(st.failed,"Неуспешни")+stat(s.post_language,"Език");
    var ap=s.autopilot, box=$("autopilot-box");
    box.innerHTML = (ap.running
        ? '<button class="btn bad" onclick="autopilot(\'stop\')">Спри автопилота</button>'
        : '<button class="btn ok" onclick="autopilot(\'start\')">Старт на автопилота</button>')
      + ' <span class="muted">'+ (ap.running ? ("следващо: "+(ap.next_run_at||"скоро")) :
          (s.configured?"готов за стартиране":"завършете настройката")) +
        (ap.last_run_at? (" · последно: "+ap.last_run_at+" ("+(ap.last_result||"")+")"):"") +'</span>';
  });
}
function stat(n,l){return '<div class="stat"><div class="n">'+n+'</div><div class="l">'+l+'</div></div>';}

function loadConfig(){
  getJSON("/api/config").then(function(c){
    $("ai_provider").value=c.ai_provider;
    $("gemini_model").value=c.gemini_model; $("openai_model").value=c.openai_model;
    $("openai-have").textContent=c.has_openai_key?"(зададен)":"";
    $("fb_app_id").value=c.fb_app_id||""; $("fb-have-secret").textContent=c.has_fb_app_secret?"(зададен)":"";
    $("schedule_mode").value=c.schedule_mode;
    $("schedule_interval_minutes").value=c.schedule_interval_minutes;
    $("schedule_times").value=c.schedule_times;
    $("post_language").value=c.post_language==="English"?"English":"Bulgarian";
    $("post_max_chars").value=c.post_max_chars;
    $("run_on_start").checked=c.run_on_start; $("dry_run").checked=c.dry_run;
    $("fb-status").textContent=c.has_fb_token?("свързана страница: "+(c.fb_page_id||"")):"не е свързана";
    toggleProvider(); toggleSchedule();
  });
}
function toggleProvider(){var o=$("ai_provider").value==="openai";$("openai-box").classList.toggle("hide",!o);$("gemini-box").classList.toggle("hide",o);}
function toggleSchedule(){var d=$("schedule_mode").value==="daily";$("times-box").classList.toggle("hide",!d);$("interval-box").classList.toggle("hide",d);}
$("ai_provider").addEventListener("change",toggleProvider);
$("schedule_mode").addEventListener("change",toggleSchedule);

function saveConfig(){
  var b={ai_provider:$("ai_provider").value,gemini_model:$("gemini_model").value,
    openai_model:$("openai_model").value,openai_api_key:$("openai_api_key").value,
    schedule_mode:$("schedule_mode").value,
    schedule_interval_minutes:parseInt($("schedule_interval_minutes").value||"120",10),
    schedule_times:$("schedule_times").value,post_language:$("post_language").value,
    post_max_chars:parseInt($("post_max_chars").value||"600",10),
    run_on_start:$("run_on_start").checked,dry_run:$("dry_run").checked};
  postJSON("/api/config",b).then(function(r){toast(r.ok?"Запазено":"Грешка");$("openai_api_key").value="";loadConfig();loadStatus();});
}
function loginGemini(){toast("Отваря се браузър за вход…");$("gemini-status").textContent="влизане…";
  postJSON("/api/login-gemini",{}).then(function(r){$("gemini-status").textContent=r.logged_in?"✓ влязъл":("✕ "+(r.error||"неуспех"));loadStatus();});}
function fbConnect(){toast("Отваря се браузър за Facebook…");$("fb-status").textContent="свързване…";
  postJSON("/api/facebook/connect",{fb_app_id:$("fb_app_id").value,fb_app_secret:$("fb_app_secret").value}).then(function(r){
    $("fb-status").textContent=r.ok?("✓ "+r.page_name+" ("+r.page_id+")"):("✕ "+(r.error||"неуспех"));
    $("fb_app_secret").value="";loadStatus();});}

function act(url,msg){toast(msg);var o=$("action-out");o.classList.remove("hide");o.textContent=msg;document.body.classList.add("busy");
  postJSON(url,{}).then(function(r){document.body.classList.remove("busy");
    if(r.ok){o.textContent=(r.text!==undefined?r.text:("Готово · обновени: "+(r.updated!==undefined?r.updated:"")))+(r.published?"\\n\\n✓ Публикувано (id "+r.post_id+")":(r.published===false?"\\n\\n(тестов преглед — не е публикувано)":""));}
    else{o.textContent="✕ "+(r.error||"Грешка");}
    loadStatus();});}

function autopilot(a){postJSON("/api/autopilot",{action:a}).then(function(r){if(!r.ok)toast(r.error||"Грешка");loadStatus();});}

function loadPosts(){getJSON("/api/posts").then(function(d){
  $("posts-body").innerHTML=d.posts.map(function(p){
    var txt=(p.content||"").replace(/</g,"&lt;");if(txt.length>120)txt=txt.slice(0,120)+"…";
    return "<tr><td>"+(p.created_at||"")+"</td><td><span class=\"tag "+p.status+"\">"+p.status+"</span></td>"+
      "<td>"+txt+"</td><td>"+(p.likes||0)+"</td><td>"+(p.comments||0)+"</td><td>"+(p.shares||0)+"</td></tr>";
  }).join("")||"<tr><td colspan=6 class=muted>Все още няма публикации.</td></tr>";});}
function loadLogs(){getJSON("/api/logs").then(function(d){var v=$("log-view");v.textContent=d.log;v.scrollTop=v.scrollHeight;});}
function loadMemory(){getJSON("/api/memory").then(function(m){
  $("steering-view").textContent=m.steering||"(още няма)";
  BIZ.forEach(function(f){ /* keep what's typed; only prefill empties from saved md is complex — leave editable */ });});}

function saveBusiness(){var b={};BIZ.forEach(function(f){b[f[0]]=$("biz_"+f[0]).value;});
  postJSON("/api/business",b).then(function(r){toast(r.ok?"Профилът е запазен":(r.error||"Грешка"));});}
function sendFeedback(){var t=$("feedback").value.trim();if(!t){toast("Напишете нещо");return;}toast("Съгласувам стила…");
  postJSON("/api/feedback",{feedback:t}).then(function(r){if(r.ok){$("feedback").value="";$("steering-view").textContent=r.steering;toast("Стилът е обновен");}else toast(r.error||"Грешка");});}

loadStatus();loadConfig();
setInterval(function(){loadStatus();var l=$("tab-logs");if(l&&!l.classList.contains("hide"))loadLogs();var p=$("tab-posts");if(p&&!p.classList.contains("hide"))loadPosts();},5000);
</script>
</body></html>"""
