#!/usr/bin/env bash
set -euo pipefail
printf "%s\n" "This is a review-only example. No AWS resources were changed. Read README.md." >&2
exit 1
